#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "symbol_table_header.h"

#define INTMAX 5

static int line_number = 1;
static int scope = 1;
static store_table **symbol_table;
static char* iden_name_global = NULL;
static char type_int[4] = "int";
static char type_string[7] = "string";
static char type_vector[7] = "vector";


char st[100][10];
int top=0;
char i_[2]="0";
char temp[2]="t";

int if_label[20];
int if_lnum=0;
int if_ltop=0;

int while_lnum=1;
int while_start=1;

int for_lnum=1;
int for_start=1;


int check_scope(char *other_symbol){
	if (strcmp(other_symbol,"{")==0)
		scope++;
	if (strcmp(other_symbol,"}")==0)
		scope--;
	//printf("in check_scope %s\n scope value=%d", other_symbol,scope);
	return scope;
}


void init()
{
    iden_name_global = (char*)malloc(sizeof(char)*100);
    symbol_table = malloc(_maxsize * sizeof(store_table*));
    for(int i = 0; i < _maxsize; i++)
    {
        symbol_table[i] = NULL;
    }
    return;
}

store_table *lookup(char *identifier_name, int* insert_at_index, store_table* prev_ptr)
{
    //printf("in lookup -> %s",identifier_name);
    store_table *tokenptr = symbol_table[0];
    store_table *prevdat_ptr = NULL;
    *insert_at_index = 0;
    while ((tokenptr != NULL) && (strcmp(identifier_name,tokenptr->iden_name) != 0))
    {
        prevdat_ptr = tokenptr;
        *insert_at_index = *insert_at_index + 1;
        tokenptr = symbol_table[*insert_at_index];
    }
    return tokenptr;
}

void insert_to_symbol_table(char *identifier_name, void* value, char* type)
{
    // printf("Values recieved - %s - Identifier\t%s - type\n",identifier_name,type);
    // printf("Values recieved - %s - Identifier\t%d - Value\t%s - type\n", identifier_name, (int)value, type);
    //printf("in insert to symbol table -> %s",identifier_name);
    store_table *tokenptr = symbol_table[0];
    store_table *prev_ptr = NULL;

    int* insert_at_index = (int *)malloc(sizeof(int));

    tokenptr = lookup(identifier_name, insert_at_index, prev_ptr);

    if(tokenptr == NULL)
    {
        tokenptr = (store_table*)malloc(sizeof(store_table));
        strncpy(tokenptr->iden_name, identifier_name, strlen(identifier_name));
        strncpy(tokenptr->type, type, strlen(type));
        tokenptr->lines = (tok_occ*)malloc(sizeof(tok_occ));
        tokenptr->lines->line_number = line_number - 1;
	    tokenptr->lines->scope_of_id = scope;
        tokenptr->lines->next = NULL;
        // tokenptr->values = (tokeninfo*)malloc(sizeof(tokeninfo)*INTMAX);
        tokenptr->lines->values = (tokeninfo*)malloc(sizeof(tokeninfo));
        
        if (strcmp(type, type_int) == 0)
        {
            tokenptr->lines->values->value = (int)value;
        }

        else if (strcmp(type, type_string) == 0)
        {
            tokenptr->lines->values->stringval = (char *)value;
        }
        
        tokenptr->next = NULL;
        symbol_table[*insert_at_index] = tokenptr;
    }
    else
    {
        tok_occ *line_no_ptr = tokenptr->lines;

        while (line_no_ptr->next != NULL)
        {
            line_no_ptr = line_no_ptr->next;
        }

        line_no_ptr->next = (tok_occ*)malloc(sizeof(tok_occ));
        line_no_ptr->next->line_number = line_number - 1;
	    line_no_ptr->next->scope_of_id = scope;
        line_no_ptr->next->next = NULL;
        line_no_ptr->next->values = (tokeninfo*)malloc(sizeof(tokeninfo));

        if (strcmp(type, type_int) == 0)
        {
            line_no_ptr->next->values->value = (int)value;
        }

        else if (strcmp(type, type_string) == 0)
        {
            line_no_ptr->next->values->stringval = (char *)value;
        }
    }
    return;
}

void insert_to_symbol_table_identifier(const char* identifier_name)
{
    strcpy(iden_name_global, identifier_name);
    printf("%s Copied globally\n",iden_name_global);
    return;
}

void insert_to_symbol_table_value(void* value, char* type)
{
    insert_to_symbol_table(iden_name_global, value, type);
    return;
}

void incrline()
{
    line_number++;
    return;
}

void dump_to_file(FILE *of)
{  
  char blank[1] = "";
  fprintf(of,"---------------\t\t\t------------\t\t\t------\t\t\t------\n");
  fprintf(of,"Identifier Name\t\t\tLine Numbers\t\t\t Scope\t\t\t Value\n");
  fprintf(of,"---------------\t\t\t------------\t\t\t------\t\t\t------\n");
  for (int i=0; i < _maxsize; ++i){
    if (symbol_table[i] != NULL)
    {
        store_table *tokenptr = symbol_table[i];
        while (tokenptr != NULL)
        {
            tok_occ *line_no_ptr = tokenptr->lines;
            tok_occ *scope_ptr = tokenptr->lines;
            tok_occ *value_ptr = tokenptr->lines;
            fprintf(of,"%-20s ",tokenptr->iden_name);
            while (line_no_ptr != NULL)
            {
                fprintf(of,"%4d ",line_no_ptr->line_number);
                fprintf(of,"\t\t\t\t\t\t");
                fprintf(of,"%4d ",scope_ptr->scope_of_id);
                fprintf(of,"\t\t\t");
                
                if (strcmp(tokenptr->type, type_int) == 0)
                {
                    fprintf(of,"%-10d ",value_ptr->values->value);
                }

                else if (strcmp(tokenptr->type, type_string) == 0 )
                {
                    fprintf(of,"%-10s ",value_ptr->values->stringval);
                }

                else
                {
                    fprintf(of,"Vector value");
                }
                
                line_no_ptr = line_no_ptr->next;
                scope_ptr = scope_ptr->next;
                value_ptr = value_ptr->next;
                fprintf(of,"\n");
                fprintf(of,"%-20s ",blank);
            }
	        
            fprintf(of,"\n");
            tokenptr = tokenptr->next;
        }
    }
  }
}







void concatenate(char p[], char q[]) {
   int c, d;
   
   c = 0;
 
   while (p[c] != '\0') {
      c++;      
   }
 
   d = 0;
 
   while (q[d] != '\0') {
      p[c] = q[d];
      d++;
      c++;    
   }
 
   p[c] = '\0';
}

void push(char *s)
{
    
    //printf("\nin push \n");
    printf("\n %s pushed yayy\n",s);
    strcpy(st[++top],s);
    printf("Push Success\n\n");
}

void codegen()
{
    printf("\nin codegen \n");
    // printf("\nin codegen  \n");


    strcpy(temp,"t");
    // printf("\nin codegen %s, %s \n",temp, i_);

    concatenate(temp,i_);

    // printf("\nin codegen %s   #####\n", temp);

    // printf("\nin codegen after \n");


    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 
    // fprintf(fptr, "in codegen\n %s = %s %s %s\n",temp,st[top-2],st[top-1],st[top]); // write to file 
    fprintf(fptr, "%s = %s %s %s\n",temp,st[top-2],st[top-1],st[top]); // write to file 
    fclose(fptr);

    // printf("in codegen\n %s = %s %s %s\n",temp,st[top-2],st[top-1],st[top]);

    //insert_to_quadruple();
    top-=2;
    strcpy(st[top],temp);
    i_[0]++;
}

void codegen_assign()
{
    // printf("\nin codegen assign \n");

    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 
    // fprintf(fptr,"in codegen_assign\n %s = %s\n",st[top-2],st[top]);
    fprintf(fptr,"%s = %s\n",st[top-2],st[top]);

    fclose(fptr);

    // printf("in codegen_assign\n %s = %s\n",st[top-2],st[top]);
    top-=2;
}


// void codegen_umin()
// {
// strcpy(temp,"t");
// concatenate(temp,i_);
// printf("in codegen_umin \n %s = -%s\n",temp,st[top]);
// top--;
// strcpy(st[top],temp);
// i_[0]++;
// }


void if_lab1()
{

    printf("\nin if_lab1 \n");

    if_lnum++;
    strcpy(temp,"t");
    concatenate(temp,i_);

    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"%s = not %s\n",temp,st[top]);
    fprintf(fptr,"if %s goto L%d\n",temp,if_lnum);
    //  printf("%s = not %s\n",temp,st[top]);
    //  printf("if %s goto L%d\n",temp,if_lnum);
    fclose(fptr);
    i_[0]++;
    if_label[++if_ltop]=if_lnum;
}

void if_lab2()
{
    printf("\nin if_lab2 \n");

    int x;
    if_lnum++;
    x=if_label[if_ltop--];

    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 
    fprintf(fptr,"goto L%d\n",if_lnum);
    fprintf(fptr,"L%d: \n",x);
    fclose(fptr);
    // printf("goto L%d\n",if_lnum);
    // printf("L%d: \n",x);
    if_label[++if_ltop]=if_lnum;
}

void if_lab3()
{
    printf("\nin if_lab3 \n");

    int y;
    y=if_label[if_ltop--];

    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"L%d: \n",y);
    // printf("L%d: \n",y);
    fclose(fptr);
}

void while_lab1()
{
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 
    fprintf(fptr,"L%d: \n",while_lnum);
    fclose(fptr);
    while_lnum++;
    // printf("L%d: \n",while_lnum++);

}

void while_lab2()
{
    strcpy(temp,"t");
    concatenate(temp,i_);
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"%s = not %s\n",temp,st[top]);
    fprintf(fptr,"if %s goto L%d\n",temp,while_lnum);
    fclose(fptr);
    // printf("%s = not %s\n",temp,st[top]);
    // printf("if %s goto L%d\n",temp,while_lnum);
    i_[0]++;
 }

void while_lab3()
{
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"goto L%d \n",while_start);
    fprintf(fptr,"L%d: \n",while_lnum);
    fclose(fptr);
    // printf("goto L%d \n",while_start);
    // printf("L%d: \n",while_lnum);
}

void for_lab1()
{
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 
    fprintf(fptr,"L%d: \n",for_lnum);
    fclose(fptr);
    for_lnum++;
    // printf("L%d: \n",for_lnum++);

}

void for_lab2()
{
    strcpy(temp,"t");
    concatenate(temp,i_);
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"%s = not %s\n",temp,st[top]);
    fprintf(fptr,"if %s goto L%d\n",temp,for_lnum);
    fclose(fptr);
    // printf("%s = not %s\n",temp,st[top]);
    // printf("if %s goto L%d\n",temp,for_lnum);
    i_[0]++;
 }

void for_lab3()
{
    FILE *fptr = fopen("3AC_output.txt", "a"); // write only 

    fprintf(fptr,"goto L%d \n",for_start);
    fprintf(fptr,"L%d: \n",for_lnum);
    fclose(fptr);
    // printf("goto L%d \n",while_start);
    // printf("L%d: \n",for_lnum);
}