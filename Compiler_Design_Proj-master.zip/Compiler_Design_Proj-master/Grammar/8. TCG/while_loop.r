i=1
while (testvar > 2)
{
    print(testvar)
    testvar = testvar - 1
}
