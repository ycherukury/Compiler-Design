count <- 1
repeat {
    if ( count > 3 )
    {
        break
    }
}
