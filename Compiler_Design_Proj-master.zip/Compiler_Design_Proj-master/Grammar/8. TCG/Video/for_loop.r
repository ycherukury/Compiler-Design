for ( i in seq ( 1 , 6 ) ) 
{ 
    expression1 = expression1 + 1 
}
