abcezxc <- 2345
dummy = 6789
expression1 <<- 1 + 2 * 3 - 4 / 5
dps = 'abcdefg'
1234 -> id_reverse
