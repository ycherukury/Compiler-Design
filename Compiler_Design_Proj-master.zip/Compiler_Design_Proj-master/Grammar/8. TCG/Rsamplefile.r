# A sample R program

# Constructs
# - For
# - While
# - Repeat

# Additional implementation
# - If loop

# Variable declarations
abcezxc = 2345
hithere = 6789
expression1 = 1+2+3+4+5

# String declaration
dps = 'abcdefg'

# Vector Declaration
defg <- c(1, 2, 3, 4, 5, 6, 'abcdefg', 'how')

# For loop
for (i in seq(1,6))
{
    expression1 = expression1 + 1
}

# While loop
testvar <- 10
while (testvar > 2)
{
    print(testvar)
    testvar = testvar - 1
}

# Repeat loop
count <- 1
repeat {
    if(count > 3)
    {
        break
    } else {
        count <- count + 2
    }
}

# If loop - additional implementation
a <- 5
if(defg[1] < 8) 
{
    print("HEY")
} else {
    print("Hello")
}


