defg <- c(1,2,3,4,5,6, 'abcdefg', 'how')
