a[1] <- fer
