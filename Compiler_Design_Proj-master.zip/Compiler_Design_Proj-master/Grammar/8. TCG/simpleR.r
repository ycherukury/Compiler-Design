expression1 = 1+2+3+4+5
for (i in seq(1,6))
{
    expression1 = expression1 + 1
}
