defg <- c(1,2,3,4,5,6, 'abcdefg', 'how')
a <- 5
if(defg[1] < 8) 
{
    print("HEY")
} else {
    print("Hello")
}
