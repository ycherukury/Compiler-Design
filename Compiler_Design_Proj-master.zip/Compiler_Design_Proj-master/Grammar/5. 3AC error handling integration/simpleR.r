if(a < 10) 
{
repeat {
    print(count)
    count = count + 1
    repeat {
        dps <- 2
        heythere <- 10
    }
}
}
