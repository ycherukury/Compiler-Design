repeat {
    print(count)
    count = count + 1
    if(count > 10) 
    {
        print(count)
        break
    } else {
        print("NOPE")
    }
}
