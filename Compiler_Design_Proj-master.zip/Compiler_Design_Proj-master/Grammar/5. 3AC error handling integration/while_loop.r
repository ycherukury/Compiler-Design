while (testvar > 2)
{
    print(testvar)
    testvar = testvar - 1
}
