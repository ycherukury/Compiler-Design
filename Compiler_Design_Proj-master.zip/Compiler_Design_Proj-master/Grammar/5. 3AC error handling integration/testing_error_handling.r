if(a < 10) 
{
    print(a)
} else {
    print("NOPE")
}
