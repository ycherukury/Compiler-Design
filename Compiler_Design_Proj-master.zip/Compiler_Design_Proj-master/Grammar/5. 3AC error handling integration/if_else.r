if(a < 10) 
{
    b=100
} else {
   c = c+1
}
