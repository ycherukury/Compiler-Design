for (i in seq(1,6))
{
    print(i)
}
