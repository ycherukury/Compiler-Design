a = 2345
hithere = 6789
expression1 = 1+2+3+4+5
b="hey"
# a <- c(1,2,3,4,5,6)
# a + c(2,4) #hjk
for (i in seq(1,6))
{
    print(i)
}
testvar <- 10
while (testvar > 2)
{
    print(testvar)
    testvar = testvar - 1
}
count <- 1
repeat {
    print(count)
    count = count + 1
    if(count == 9)
    {
        dps <- 2
        heythere <- 10
    }
}
a <- 5
if(a < 10) 
{
    print(a)
} else {
    print("NOPE")
}
