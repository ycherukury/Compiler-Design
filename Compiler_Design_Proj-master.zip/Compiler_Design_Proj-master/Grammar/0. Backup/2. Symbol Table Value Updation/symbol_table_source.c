#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol_table_header.h"

#define INTMAX 5

static int line_number = 1;
static int scope = 1;
static store_table **symbol_table;
static char* iden_name_global = NULL;
static char type_int[4] = "int";
static char type_string[7] = "string";
static char type_vector[7] = "vector";

int check_scope(char *other_symbol){
	if (strcmp(other_symbol,"{")==0)
		scope++;
	if (strcmp(other_symbol,"}")==0)
		scope--;
	//printf("in check_scope %s\n scope value=%d", other_symbol,scope);
	return scope;
}


void init()
{
    iden_name_global = (char*)malloc(sizeof(char)*100);
    symbol_table = malloc(_maxsize * sizeof(store_table*));
    for(int i = 0; i < _maxsize; i++)
    {
        symbol_table[i] = NULL;
    }
    return;
}

store_table *lookup(char *identifier_name, int* insert_at_index, store_table* prev_ptr)
{
    //printf("in lookup -> %s",identifier_name);
    store_table *tokenptr = symbol_table[0];
    store_table *prevdat_ptr = NULL;
    *insert_at_index = 0;
    while ((tokenptr != NULL) && (strcmp(identifier_name,tokenptr->iden_name) != 0))
    {
        prevdat_ptr = tokenptr;
        *insert_at_index = *insert_at_index + 1;
        tokenptr = symbol_table[*insert_at_index];
    }
    return tokenptr;
}

void insert_to_symbol_table(char *identifier_name, void* value, char* type)
{
    // printf("Values recieved - %s - Identifier\t%s - type\n",identifier_name,type);
    // printf("Values recieved - %s - Identifier\t%d - Value\t%s - type\n", identifier_name, (int)value, type);
    //printf("in insert to symbol table -> %s",identifier_name);
    store_table *tokenptr = symbol_table[0];
    store_table *prev_ptr = NULL;

    int* insert_at_index = (int *)malloc(sizeof(int));

    tokenptr = lookup(identifier_name, insert_at_index, prev_ptr);

    if(tokenptr == NULL)
    {
        tokenptr = (store_table*)malloc(sizeof(store_table));
        strncpy(tokenptr->iden_name, identifier_name, strlen(identifier_name));
        strncpy(tokenptr->type, type, strlen(type));
        tokenptr->lines = (tok_occ*)malloc(sizeof(tok_occ));
        tokenptr->lines->line_number = line_number - 1;
	    tokenptr->lines->scope_of_id = scope;
        tokenptr->lines->next = NULL;
        // tokenptr->values = (tokeninfo*)malloc(sizeof(tokeninfo)*INTMAX);
        tokenptr->lines->values = (tokeninfo*)malloc(sizeof(tokeninfo));
        
        if (strcmp(type, type_int) == 0)
        {
            tokenptr->lines->values->value = (int)value;
        }

        else if (strcmp(type, type_string) == 0)
        {
            tokenptr->lines->values->stringval = (char *)value;
        }
        
        tokenptr->next = NULL;
        symbol_table[*insert_at_index] = tokenptr;
    }
    else
    {
        tok_occ *line_no_ptr = tokenptr->lines;

        while (line_no_ptr->next != NULL)
        {
            line_no_ptr = line_no_ptr->next;
        }

        line_no_ptr->next = (tok_occ*)malloc(sizeof(tok_occ));
        line_no_ptr->next->line_number = line_number - 1;
	    line_no_ptr->next->scope_of_id = scope;
        line_no_ptr->next->next = NULL;
        line_no_ptr->next->values = (tokeninfo*)malloc(sizeof(tokeninfo));

        if (strcmp(type, type_int) == 0)
        {
            line_no_ptr->next->values->value = (int)value;
        }

        else if (strcmp(type, type_string) == 0)
        {
            line_no_ptr->next->values->stringval = (char *)value;
        }
    }
    return;
}

void insert_to_symbol_table_identifier(const char* identifier_name)
{
    strcpy(iden_name_global, identifier_name);
    printf("%s Copied globally\n",iden_name_global);
    return;
}

void insert_to_symbol_table_value(void* value, char* type)
{
    insert_to_symbol_table(iden_name_global, value, type);
    return;
}

void incrline()
{
    line_number++;
    return;
}

void dump_to_file(FILE *of)
{  
  char blank[1] = "";
  fprintf(of,"---------------\t\t\t------------\t\t\t------\t\t\t------\n");
  fprintf(of,"Identifier Name\t\t\tLine Numbers\t\t\t Scope\t\t\t Value\n");
  fprintf(of,"---------------\t\t\t------------\t\t\t------\t\t\t------\n");
  for (int i=0; i < _maxsize; ++i){
    if (symbol_table[i] != NULL)
    {
        store_table *tokenptr = symbol_table[i];
        while (tokenptr != NULL)
        {
            tok_occ *line_no_ptr = tokenptr->lines;
            tok_occ *scope_ptr = tokenptr->lines;
            tok_occ *value_ptr = tokenptr->lines;
            fprintf(of,"%-20s ",tokenptr->iden_name);
            while (line_no_ptr != NULL)
            {
                fprintf(of,"%4d ",line_no_ptr->line_number);
                fprintf(of,"\t\t\t\t\t\t");
                fprintf(of,"%4d ",scope_ptr->scope_of_id);
                fprintf(of,"\t\t\t");
                
                if (strcmp(tokenptr->type, type_int) == 0)
                {
                    fprintf(of,"%-10d ",value_ptr->values->value);
                }

                else if (strcmp(tokenptr->type, type_string) == 0 )
                {
                    fprintf(of,"%-10s ",value_ptr->values->stringval);
                }

                else
                {
                    fprintf(of,"Vector value");
                }
                
                line_no_ptr = line_no_ptr->next;
                scope_ptr = scope_ptr->next;
                value_ptr = value_ptr->next;
                fprintf(of,"\n");
                fprintf(of,"%-20s ",blank);
            }
	        
            fprintf(of,"\n");
            tokenptr = tokenptr->next;
        }
    }
  }
}
