a <- 5
if(a < 10) 
{
    print(a)
    k <- 5
}
