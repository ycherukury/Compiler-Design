if(a < 10) 
{
    print(a)
} else {
    print("NOPE")
}
d <-<- 45
ghi <-- 67
fi(a < 10) 
{
    print(a)
} 
else 
{
    print("NOPE")
}
