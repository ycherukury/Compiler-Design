#include <stdio.h>
#define _maxsize 1000
#define _toklen 50
 
char* __identifier_name;

typedef struct tokeninfo{
    int value; 
    double floatvalue; 
    char *stringval;
}tokeninfo;

typedef struct tok_occ{
    int line_number;
    int scope_of_id;
    tokeninfo *values;
    struct tok_occ *next;
}tok_occ;
 
typedef struct store_table{
    char iden_name[_toklen];
    char type[_toklen];
    tok_occ *lines;
    tokeninfo *values;
    struct store_table *next;
}store_table;

void init();
void insert_to_symbol_table(char *name, void* value, char* type);
void insert_to_symbol_table_identifier(const char* identifier_name);
void insert_to_symbol_table_value(void* value, char* type);
void dump_to_file(FILE *op);
store_table *lookup(char *name, int* insert_at_index, store_table* prev_ptr);
void incrline();
int check_scope(char *name);


typedef struct quadruple {
    char op;
    char arg1;
    char arg2;
    char result;

}quadruple; 

void insert_to_quadruple();
void push(char *s);
void codegen();
void codegen_assign();
void concatenate(char p[], char q[]);
void if_lab1();
void if_lab2();
void if_lab3();
void while_lab1();
void while_lab2();
void while_lab3();
void for_lab1();
void for_lab2();
void for_lab3();
